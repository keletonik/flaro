# FIP / VESDA Master Build Pack
**Version:** 2.0 — Consolidated and corrected  
**Purpose:** Complete build pack for the FIP/VESDA technical knowledge backend and AIDE desktop integration

---

## What This Pack Contains

| File | Purpose |
|------|---------|
| 01_FIP_SOURCE_MANIFEST.json | All manual/doc URLs by vendor |
| 02_FIP_SOURCE_MANIFEST.csv | Same as above, spreadsheet format |
| 03_MISSING_ITEMS.json | Gap register — what still needs to be acquired |
| 04_MISSING_ITEMS.csv | Same as above, spreadsheet format |
| 05_STANDARDS_REGISTER.json | Australian standards mapped to fire systems |
| 06_STANDARDS_REGISTER.csv | Same as above |
| 07_STANDARDS_GAP_LIST.json | Standards not yet recovered as standalone files |
| 08_BACKEND_ARCHITECTURE.md | Full SQL schema, API spec, Replit/GitHub deployment |
| 09_AIDE_DESKTOP_INTEGRATION.md | Feature spec for AIDE desktop module |
| 10_CLAUDE_CODE_PROMPT.md | The exact prompt to paste into Claude Code |
| 11_AUDIT_CHECKLIST.md | Multi-pass verification framework |

---

## Load Order for Claude Code

1. `10_CLAUDE_CODE_PROMPT.md` — paste this first
2. `08_BACKEND_ARCHITECTURE.md` — architecture reference
3. `01_FIP_SOURCE_MANIFEST.json` — seed data
4. `03_MISSING_ITEMS.json` — gap tracking
5. `05_STANDARDS_REGISTER.json` — standards context

---

## What Is Being Built

### Phase 1 (this pack): AIDE Desktop Integration
FIP/VESDA troubleshooting built directly into the existing AIDE platform.  
No separate mobile app. No separate product. AIDE first.

### Phase 2 (later): Field Mobile App
Separate mobile application for technicians onsite.  
Will share the same backend built in Phase 1.

---

## Stack
- Monorepo: pnpm workspace
- Language: TypeScript
- Frontend: React + Vite
- Backend: Express 5
- Database: PostgreSQL + Drizzle ORM
- Validation: Zod
- AI: Anthropic (already integrated in AIDE)
- Deployment: Replit
