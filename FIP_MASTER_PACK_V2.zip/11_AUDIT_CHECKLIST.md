# Multi-Pass Audit and Verification Framework
**Purpose:** Prevent incomplete builds, silent failures, and false completion claims

---

## AUDIT PASS 1 — Repository and Structure

Run after Phase 1 (repo analysis and architecture):

- [ ] All required lib/ packages created with correct structure
- [ ] All required artifacts/aide/src/modules/fip/ directories created
- [ ] All required API route groups registered
- [ ] No forbidden binaries in GitHub repo
- [ ] .env.example exists with all required variable names
- [ ] Package.json/workspace config correct for new packages

**Gate:** Confirmed before any code is written

---

## AUDIT PASS 2 — Database Schema

Run after Phase 2 (schema and migrations):

- [ ] manufacturers table exists with correct columns
- [ ] product_families table exists with FK to manufacturers
- [ ] models table exists with self-referencing successor_model_id
- [ ] components table exists with FK to models
- [ ] source_locations table exists with UNIQUE on source_uri
- [ ] documents table exists with all status enums
- [ ] document_sections table exists with self-referencing parent
- [ ] standards table exists with UNIQUE on (standard_code, edition_year)
- [ ] compatibility_links table exists
- [ ] fault_signatures table exists with fault_category enum
- [ ] troubleshooting_sessions table exists
- [ ] session_images table exists
- [ ] image_identification_results table exists
- [ ] supplier_products table exists
- [ ] repair_estimates table exists
- [ ] escalation_packs table exists
- [ ] audit_runs table exists
- [ ] All required indexes created
- [ ] Migrations run clean on empty database
- [ ] Rollback works

**Gate:** schema audit PASS before Phase 3

---

## AUDIT PASS 3 — Storage Integration

Run after Phase 3 (storage):

- [ ] Storage client initialises
- [ ] Upload returns a storage_uri
- [ ] Download from storage_uri succeeds
- [ ] SHA256 checksum calculated and stored
- [ ] Missing-file handling doesn't crash
- [ ] Lifecycle policy configured if required

**Gate:** storage round-trip PASS before Phase 4

---

## AUDIT PASS 4 — Ingestion

Run after Phase 4 (source registry and ingestion):

- [ ] Source registration creates source_locations record
- [ ] Duplicate source_uri is handled without crashing
- [ ] Document ingest stores metadata in documents table
- [ ] Document ingest stores binary in object storage
- [ ] Checksum is calculated and stored
- [ ] Indirect/gated sources are flagged correctly
- [ ] Failed ingestions are recorded, not silently dropped
- [ ] Seed import from 01_FIP_SOURCE_MANIFEST.json runs cleanly

**Gate:** ingestion audit PASS before Phase 5

---

## AUDIT PASS 5 — Knowledge Retrieval

Run after Phase 5 (knowledge retrieval):

- [ ] GET /api/fip/models/search returns results for "Ampac"
- [ ] GET /api/fip/manuals returns results for a known model_id
- [ ] GET /api/fip/faults/search returns results for "ground fault"
- [ ] GET /api/fip/standards/code/AS 1670.1 returns record
- [ ] GET /api/fip/models/:id/compatible-parts returns results where data exists
- [ ] Every result includes source reference and trust level
- [ ] Empty results explicitly return empty, not error

**Gate:** retrieval audit PASS before Phase 6

---

## AUDIT PASS 6 — Image Identification Pipeline

Run after Phase 6 (identification):

- [ ] POST /api/fip/identify/panel accepts image upload
- [ ] Image is stored in object storage
- [ ] session_images record is created
- [ ] image_identification_results record is created
- [ ] Result includes top candidate with confidence
- [ ] Result includes alternatives
- [ ] Low-confidence result is flagged (not silently accepted)
- [ ] User confirmation/override endpoint works
- [ ] Full audit trail from image to confirmed result exists

**Gate:** identification flow PASS before Phase 7

---

## AUDIT PASS 7 — Troubleshooting Sessions

Run after Phase 7 (sessions):

- [ ] POST /api/fip/sessions creates session record
- [ ] POST /api/fip/sessions/:id/symptom returns ranked fault matches
- [ ] POST /api/fip/sessions/:id/step-result records step with timestamp
- [ ] GET /api/fip/sessions/:id/next-actions returns next recommended actions
- [ ] Session status updates correctly
- [ ] Escalation trigger detected when evidence is insufficient
- [ ] All session data persists correctly

**Gate:** troubleshooting flow PASS before Phase 8

---

## AUDIT PASS 8 — Parts, Estimates, Escalations

Run after Phase 8:

- [ ] GET /api/fip/parts returns compatible parts for a known model
- [ ] Parts include supplier, cost band, and confidence
- [ ] POST /api/fip/estimates generates all cost components
- [ ] Estimate confidence label is set
- [ ] Estimate export payload is compatible with existing AIDE estimation
- [ ] POST /api/fip/escalations/:id/escalate compiles all session data
- [ ] Escalation pack JSON is complete
- [ ] Escalation status updates correctly

**Gate:** estimate and escalation audits PASS before Phase 9

---

## AUDIT PASS 9 — AI Assistant

Run after Phase 9 (AI integration):

- [ ] AI rapid answer returns source reference
- [ ] AI guided troubleshooting branches correctly on step result
- [ ] AI parts suggestion includes confidence label
- [ ] AI "not found" case returns explicit unresolved flag, not fabricated answer
- [ ] AI never produces part numbers not in supplier_products table
- [ ] AI never produces compatibility claims not in compatibility_links table
- [ ] Every AI output has source_ids, confidence_label, inference_mode

**Gate:** AI provenance audit PASS before Phase 10

---

## AUDIT PASS 10 — Desktop UI Modules

Run after Phase 10 (UI):

- [ ] Troubleshooting module loads and accepts fault code input
- [ ] KnowledgeBase module loads and returns manuals for Ampac
- [ ] Standards module loads and shows AS 1670.1 record
- [ ] PanelsDevices module loads and shows model search results
- [ ] Parts module loads and shows supplier results
- [ ] Estimates module loads and generates estimate
- [ ] Escalations module loads and shows escalation packs
- [ ] Identification module loads and accepts image upload
- [ ] All 8 modules appear in AIDE nav
- [ ] Job link-out works from session view
- [ ] Defect link-out works from session view
- [ ] Estimate export to AIDE estimation works

**Gate:** desktop UI audit PASS before Phase 11

---

## AUDIT PASS 11 — Audit Subsystem and Tests

Run after Phase 11:

- [ ] All audit runners execute without crashing
- [ ] Each audit runner produces machine-readable JSON output
- [ ] audit_runs records persist for every audit execution
- [ ] Unit test suite: all tests pass
- [ ] Integration tests: all smoke tests pass
- [ ] npm test / pnpm test runs clean

**Gate:** all audits produce JSON, all tests pass

---

## FINAL AUDIT — Deployment Readiness

Run after Phase 12:

- [ ] GET /health returns 200
- [ ] GET /health/database returns 200
- [ ] GET /health/storage returns 200
- [ ] Migrations run on clean Replit database
- [ ] App starts without fatal errors
- [ ] No secrets committed to GitHub
- [ ] No bulk binaries in GitHub
- [ ] AIDE nav includes all FIP module routes
- [ ] All audit JSON reports exist in audit_runs table

**Gate:** DEPLOYMENT PASS — all gates green

---

## Three-Pass Independent Verification

Before calling the build done, three independent passes must complete:

### Pass 1 — Source grounding
Verify: every document in documents table has a real source_location_id.  
Verify: every AI output cites a real source_id from the database.  
Verify: no fabricated records were seeded.

### Pass 2 — Data completeness
Verify: manufacturer seed covers Ampac, Pertronic, Simplex, VESDA/Xtralis, Brooks.  
Verify: at least 5 fault_signatures exist with evidence_document_id.  
Verify: at least 3 compatibility_links exist with evidence.  
Verify: at least 5 supplier_products exist.

### Pass 3 — Feature completeness
Verify: all 8 desktop modules are accessible via AIDE nav.  
Verify: full troubleshooting session flow completes end-to-end.  
Verify: identification flow completes end-to-end.  
Verify: estimate and escalation pack complete end-to-end.

---

## Blocker Handling

If any audit fails:
- Document the failure in audit_runs with status: 'failed'
- List exact failed_checks
- Continue with all non-dependent phases
- Do not mark parent phase as complete
- Surface blockers in final output

A build with documented blockers is better than a build with hidden failures.
