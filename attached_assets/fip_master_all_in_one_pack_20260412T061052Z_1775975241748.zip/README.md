PASS — all expected packs are present in this master bundle.
